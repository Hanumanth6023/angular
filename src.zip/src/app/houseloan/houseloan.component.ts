import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-houseloan',
  templateUrl: './houseloan.component.html',
  styleUrls: ['./houseloan.component.css']
})
export class HouseloanComponent implements OnInit {
 
  val1:any;
  constructor() { }

  ngOnInit(): void {
  }
  demo1(v:any, v1:any){
    this.val1=(v*v1*0.04);
    }

}
